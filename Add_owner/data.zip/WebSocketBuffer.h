#ifndef VUSER_WEBSOCKET_BUFFER_HEADER
#define VUSER_WEBSOCKET_BUFFER_HEADER

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive0[] = "\\x4D\\x53\\x47\\x23\\x31\\x23\\x33\\x23\\x31\\x23\\x30\\x3A\\x36\\x3A\\x38\\x33"
                        "\\x3A\\x31\\x37\\x39\\x3A\\x38\\x30\\x3A\\x39\\x36\\x2C\\x31\\x33\\x3D\\x31\\x34"
                        "\\x3A\\x76\\x36\\x2E\\x33\\x33\\x62\\x30\\x32\\x20\\x54\\x72\\x69\\x61\\x6C\\x3B\x00";
long WebSocketReceiveLen0   = sizeof(WebSocketReceive0) - 1;	// (record-time: 193 bytes)

#endif

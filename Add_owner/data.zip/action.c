Action()
{

	web_url("success.txt", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t14.inf", 
		LAST);

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("cvm.higher-stark.site:8080", 
		"URL=http://cvm.higher-stark.site:8080/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/resources/fonts/varela_round-webfont.woff", "Referer=http://cvm.higher-stark.site:8080/resources/css/petclinic.css", ENDITEM, 
		"Url=/resources/fonts/montserrat-webfont.woff", "Referer=http://cvm.higher-stark.site:8080/resources/css/petclinic.css", ENDITEM, 
		"Url=/webjars/bootstrap/fonts/glyphicons-halflings-regular.woff2", "Referer=http://cvm.higher-stark.site:8080/resources/css/petclinic.css", ENDITEM, 
		"Url=/resources/images/spring-logo-dataflow.png", "Referer=http://cvm.higher-stark.site:8080/resources/css/petclinic.css", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_websocket_connect("ID=0", 
		"URI=ws://127.0.0.1:1001/?cid=521934162", 
		"Origin=moz-extension://d9645fa7-5b16-470f-aecf-c3ec0d85439b", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer/Bin="
		"\\x4D\\x53\\x47\\x23\\x31\\x23\\x32\\x23\\x31\\x23\\x30\\x3A\\x36\\x3A\\x31\\x35\\x3A\\x37\\x3A\\x30\\x2C\\x31\\x31\\x32\\x3D\\x31\\x34\\x3A\\x46\\x69\\x72\\x65\\x66\\x6F\\x78\\x2F\\x36\\x37\\x2E\\x30\\x2E\\x31\\x2C\\x31\\x31\\x33\\x3D\\x31\\x34\\x3A\\x46\\x69\\x72\\x65\\x66\\x6F\\x78\\x2F\\x36\\x37\\x2E\\x30\\x2E\\x31\\x2C\\x31\\x31\\x34\\x3D\\x32\\x37\\x3A\\x43\\x68\\x72\\x6F\\x6D\\x65\\x5F\\x52\\x65\\x6E\\x64\\x65\\x72\\x57\\x69\\x64\\x67\\x65\\x74\\x48\\x6F\\x73\\x74\\x48\\x57\\x4E\\x44\\x2C\\"
		"x31\\x31\\x36\\x3D\\x35\\x3A\\x7A\\x68\\x2D\\x43\\x4E\\x3B", 
		"IsBinary=1", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("find", 
		"URL=http://cvm.higher-stark.site:8080/owners/find", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://cvm.higher-stark.site:8080/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		LAST);

	web_revert_auto_header("DNT");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_link("Add Owner", 
		"Text=Add Owner", 
		"Snapshot=t18.inf", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_form("new", 
		"Snapshot=t19.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Douglas", ENDITEM, 
		"Name=lastName", "Value=Clark", ENDITEM, 
		"Name=address", "Value=PSC 4260, Box 2035 APO AP 18350", ENDITEM, 
		"Name=city", "Value= APO", ENDITEM, 
		"Name=telephone", "Value=8690027069", ENDITEM, 
		LAST);

	lr_think_time(8);

	web_link("Find owners", 
		"Text=Find owners", 
		"Snapshot=t20.inf", 
		LAST);

	web_submit_form("owners", 
		"Snapshot=t21.inf", 
		ITEMDATA, 
		"Name=lastName", "Value=", ENDITEM, 
		LAST);

	return 0;
}
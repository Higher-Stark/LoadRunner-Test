Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("destCity=%u5317%u4EAC; DOMAIN=www.damai.cn");

	web_add_cookie("isg=BL6-xlk5b2menLtNNUzkl6nIB9QA_4J5CyKdOGjHXoG8C17l0Iy6iX8ghxViKHqR; DOMAIN=www.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=www.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=www.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=www.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1_nKBOCChurza779kCRYYuPzaNbMi_5Cj68-kp_OkjpZ0FJ6VsCR__TB4o5D9zJ9-etoT; DOMAIN=www.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=www.damai.cn");

	web_add_cookie("_uab_collina=156032550894255089118341; DOMAIN=g.alicdn.com");

	web_add_cookie("_umdata=G673FD460EC71B1D889EF0F3A2FBD2FE95FB006; DOMAIN=g.alicdn.com");

	web_add_cookie("destCity=%u5317%u4EAC; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BHZ2mc5pN8Hmh8MlvbQsL6Egz6x4l7rREzpFUOBfYtn0Ixa9SCcK4dxVPz3qkLLp; DOMAIN=api-gw.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=api-gw.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=api-gw.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1_nKBOCChurza779kCRYYuPzaNbMi_5Cj68-kp_OkjpZ0FJ6VsCR__TB4o5D9zJ9-etoT; DOMAIN=api-gw.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BPf3n1eCZs5PDOJClK-9EJibjutBvMseunHk90mkE0Yt-Bc6UYxbbrVe3poDC6OW; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BPPzp2s2qprrIGbOOLuBpLxnivcdKIfqXl1ge6WQT5JJpBNGLfgXOlGyWhbvH9_i; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BHp6mar18_V603-ZGZjom41Uw6CcK_4Fb07ZzIRzJo3YdxqxbLtOFUABw8EOfHad; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BHh4kdy_Uds0-b1fz6LKxZMOQSYK4dxrIaQbirLpxLNmzRi3WvGs-45rgQdYhpRD; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BHZ2lc5pN8Hmh8MlvbQsL6Egz6x4l7rREzpFUOBfYtn0Ixa9SCcK4dxRPz3qkLLp; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1n4LBOCanurza77OSCRYYuPzaNbMi_5Cr6T1aubOkjpaGF96VsCR_N8B4o5D9zJ9-etuq; DOMAIN=api-gw.damai.cn");

	web_url("www.damai.cn", 
		"URL=https://www.damai.cn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://g.alicdn.com/alilog/mlog/aplus_v2.js", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1U9R8GY9YBuNjy0FgXXcxcXXa-146-1822.png", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/entry/index.js?t=216713", ENDITEM, 
		"Url=https://g.alicdn.com/kissy/k/6.2.4/??base.js,attribute.js,event-custom.js,event-base.js,io.js,io-extra.js,io-base.js,promise.js,dom-base.js,query-selector-base.js,dom-extra.js,io-form.js,event.js,event-dom-base.js,event-dom-extra.js,event-gesture.js,event-touch.js,node.js,node-base.js,node-event.js,node-anim.js,anim-transition.js,anim-base.js,json-base.js", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/nsv/1.0.60/ns_b_71_3_n.js", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/sufei_data/3.7.2/index.js", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1u1U9xmzqK1RjSZFHXXb3CpXa-64-180.png", ENDITEM, 
		"Url=https://api-gw.damai.cn/navigation.html?_ksTS=1560337100637_67&callback=jsonp68", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=1&destCity=%E5%8C%97%E4%BA%AC&_ksTS=1560337100640_85&callback=jsonp86", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1WDcISkvoK1RjSZFNXXcxMVXa-540-720.png", ENDITEM, 
		"Url=https://api-gw.damai.cn/advert.html?type=1&_ksTS=1560337100600_18&callback=jsonp19", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=100&destCity=%E5%8C%97%E4%BA%AC&_ksTS=1560337100643_127&callback=jsonp128", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=3&destCity=%E5%8C%97%E4%BA%AC&_ksTS=1560337100641_99&callback=jsonp100", ENDITEM, 
		"Url=https://api-gw.damai.cn/cityList.html?_ksTS=1560337100634_50&callback=jsonp51", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=6&destCity=%E5%8C%97%E4%BA%AC&_ksTS=1560337100643_113&callback=jsonp114", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i2/2251059038/O1CN01NS74Pi2GdSAwBoVBk_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01cPCWOe2GdSAdmixz2_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN014xkoQQ2GdSAveJXFx_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN016ZeIfj2GdSAfwsyRC_!!0-item_pic.jpg", ENDITEM, 
		LAST);

	web_add_cookie("isg=BHZ2lc5pN8Hmh8MlvbQsL6Egz6x4l7rREzpFUOBfYtn0Ixa9SCcK4dxRPz3qkLLp; DOMAIN=www.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1n4LBOCanurza77OSCRYYuPzaNbMi_5Cr6T1aubOkjpaGF96VsCR_N8B4o5D9zJ9-etuq; DOMAIN=www.damai.cn");

	web_add_cookie("destCity=%u4E0A%u6D77; DOMAIN=www.damai.cn");

	web_add_cookie("_lastvisited=gJuHFQJpXnQCAcp4CxqZ%2F85N%2C%2CgJuHFQJpXnQCAcp4CxqZ85N2I7xlBbdn%2Cjwsxirp3%2Cjwsxirp3%2C3%2C6273fb8a%2CgJuHFQJpXnQCAcp4CxqZ%2F85N%2Cjwt49aee; DOMAIN=g.alicdn.com");

	web_add_cookie("isg=BNracNNZU9XaKd95ubgIu-10I4D8C17lz2557ORTg204V3qRzJq09cDhI-HunNZ9; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3aBOCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("destCity=%u4E0A%u6D77; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BF1dbDgI3PzRiLjQIqm3AtY1ZDlXepHMhE9exR8inLTj1n0I58u7nEsABAj1DamE; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3amOCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BNzcaMFn7e9oP5mzy7YmUd9CpfqOVYB_HRg_Jrbd7UeqAXyL3mRKDzL3ZatckrjX; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3aXOCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BN7eYK8tDwm-BVvtFazE98moJ3Qgn6IZK4L9mIhnTyEcq36F8C7oKWQNp3UCiJox; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3aoOCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BF9fZCbWfhZnnnoKTKdV2MAD5rPpxLNm0vkcP_Gs_o5VgH8C-ZVZtr0WRtJbA4ve; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3apOCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BODgWJ37qSPMaxUnp5rijbv2ue6y6cSzeSyz0lrxqfuOVYB_AviOQ9Yj6T_wfnyL; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3aAOCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BGFhVBScmDC15DREnp1zfrJpeC17DtUA4GPSccM2WGjHKoH8C1__0O8siJwJ-W04; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3a4OCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("cap=dcae; DOMAIN=log.mmstat.com");

	web_add_cookie("cad=Zt6ZR60oIUEFJfiwo2QmdWwcmQJH1y3Wg0TE4wGG1WM=0001; DOMAIN=log.mmstat.com");

	web_add_cookie("cna=gJuHFZXTXxoCAcp4CxrFRT+V; DOMAIN=log.mmstat.com");

	web_link("首页", 
		"Text=首页", 
		"Snapshot=t2.inf", 
		EXTRARES, 
		"Url=https://g.alicdn.com/alilog/mlog/aplus_v2.js", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/entry/index.js?t=216713", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/nsv/1.0.60/ns_b_71_3_n.js", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/sufei_data/3.7.2/index.js", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1U9R8GY9YBuNjy0FgXXcxcXXa-146-1822.png", ENDITEM, 
		"Url=https://g.alicdn.com/alilog/oneplus/entry.js?t=216713", ENDITEM, 
		"Url=https://api-gw.damai.cn/advert.html?type=1&_ksTS=1560337110249_18&callback=jsonp19", ENDITEM, 
		"Url=https://api-gw.damai.cn/navigation.html?_ksTS=1560337110290_67&callback=jsonp68", ENDITEM, 
		"Url=https://api-gw.damai.cn/cityList.html?_ksTS=1560337110288_50&callback=jsonp51", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=1&destCity=%E4%B8%8A%E6%B5%B7&_ksTS=1560337110296_85&callback=jsonp86", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=3&destCity=%E4%B8%8A%E6%B5%B7&_ksTS=1560337110297_99&callback=jsonp100", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=6&destCity=%E4%B8%8A%E6%B5%B7&_ksTS=1560337110301_113&callback=jsonp114", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=100&destCity=%E4%B8%8A%E6%B5%B7&_ksTS=1560337110304_127&callback=jsonp128", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01QlWbR62GdSB0c94Wl_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01p3Jwcp2GdSAwWI711_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i2/2251059038/O1CN01V5SEne2GdSA9S4REp_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://log.mmstat.com/v.gif?logtype=1&title=%E5%A4%A7%E9%BA%A6%E7%BD%91-%E5%85%A8%E7%90%83%E6%BC%94%E5%87%BA%E8%B5%9B%E4%BA%8B%E5%AE%98%E6%96%B9%E8%B4%AD%E7%A5%A8%E5%B9%B3%E5%8F%B0-100%25%E6%AD%A3%E5%93%81%E3%80%81%E5%85%88%E4%BB%98%E5%85%88%E6%8A%A2%E3%80%81%E5%9C%A8%E7%BA%BF%E9%80%89%E5%BA%A7%EF%BC%81&pre=https%3A%2F%2Fwww.damai.cn%2F&scr=1280x720&cna=gJuHFQJpXnQCAcp4CxqZ/85N&spm-cnt=a2oeg.home.0.0.591b23e1FeSQgF&uidaplus=&aplus&pu_i=&asid=AQAAAADW2gBd3ckjZAAAAAA+HVZ3IrajnQ==&sidx=0&ckx=|&p"
		"=1&o=win10&b=ie11&s=1280x720&w=trident&ism=pc&cache=3ad69ab&lver=8.11.5&jsver=aplus_std&pver=0.7.1&tag=1&stag=-1&lstag=-1&_slog=0", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01qq0sEt2GdSALlIzNL_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01vvgIqX2GdSAhnknzp_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01eSbxBz2GdSAhRRDV6_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://pimg.dmcdn.cn/perform/project/1768/176844_n.jpg?_t=1559801924226", ENDITEM, 
		LAST);

	web_url("blk.html", 
		"URL=https://g.alicdn.com/alilog/oneplus/blk.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("isg=BNLSgRtx223igSeRYeCQEyWsK5i049Z9FwZhxJwr-AVwr3KphHI-jZSNG8k2xE4V; DOMAIN=online.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=online.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=online.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=online.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1k3E4OCaourza779ICRYYuPzaNbMi_5ZW6L6HGQOkjpaIFp6VsCRs08B4o5D9zJ9-etlm; DOMAIN=online.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=online.damai.cn");

	web_add_cookie("destCity=%u4E0A%u6D77; DOMAIN=online.damai.cn");

	web_url("getDialogToken", 
		"URL=https://online.damai.cn/alime/getDialogToken?_ksTS=1560337110274_37&callback=jsonCallback&from=damai_pc&jsonCallback=jsonCallback", 
		"Resource=0", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("isg=BKKiEctBC_1ShBchsdBAY3Wc-ygE86YNRxYxVOw4nJXdv0M51ILSHV986znmtB6l; DOMAIN=www.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1UVdBOfChurza77OqQO_8kPzaNbMiICP_lCW7KIOWZhvQk8XC31AZ1u6R3rViBUyBRYhhyIl.; DOMAIN=www.damai.cn");

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=www.damai.cn");

	web_add_cookie("_lastvisited=gJuHFQJpXnQCAcp4CxqZ%2F85N%2C%2CgJuHFQJpXnQCAcp4CxqZ85N2I7xlBbdn%2Cjwsxirp3%2Cjwsxirp3%2C3%2C6273fb8a%2CgJuHFQJpXnQCAcp4CxqZ%2F85N%2Cjwt4ffri; DOMAIN=g.alicdn.com");

	web_add_cookie("isg=BMPDN2p_mipbGFZeSKuxNAxXWodtOFd6ji0wy_WgHyKZtOPWfQjnyqFiKoZfD69y; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc13yjKOCanurza77OSCRYYuPzaNbMi_5BK6T_VTQOkjpafF96VsCRsV8B4o5D9zJ9-etkq; DOMAIN=api-gw.damai.cn");

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BMXFM1glNETpAhCYmqFPyv693AH_gnkU3Nf2DccqgfwLXuXQj9KJ5FN4bEANBZHM; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc16ehBOCanurza77OSCRYYuPzaNbMi_5Bh68_VTQOkjpafFJ6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BEZGKc8AZ1FWvzO1zaTcv_EQnzzIp4phQwoVoDBvMmlEM-ZNmDfacSyFD61agIJ5; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc16ehKOCanurza77OSCRYYuPzaNbMi_5Bh68_VTQOkjpafFJ6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BMnJI6TR8HhNXowMdpULBtrR0PUjFr1IOOtKuWs-RbDvsunEs2bNGLek8NSh8VWA; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc16ehoOCanurza77OSCRYYuPzaNbMi_5Bh68_VTQOkjpafFJ6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BMfHL7brVl4_NNLSJJ9tYOiLXnuRzJuu6kG0R5m049Z9COfKoZwr_gWOrgrz-3Mm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc16ehXOCanurza77OSCRYYuPzaNbMi_5Bh68_VTQOkjpafFJ6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BEhIIT32gWvkoe3vH5L6VeN-EbZa8az7kbQrGgL5lEO23ehHqgF8i96bUXcIdmTT; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc16ehmOCanurza77OSCRYYuPzaNbMi_5Bh68_VTQOkjpafFJ6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BEpKKSu8I4Uqy68pqYiY691EkzDsO86V317pXNSD9h0oh-pBvMsepZCxkzH-bEYt; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc16ehpOCanurza77OSCRYYuPzaNbMi_5Bh68_VTQOkjpafFJ6VsCRs08B4o5D9zJ9-etlm; DOMAIN=api-gw.damai.cn");

	web_url("www.damai.cn_2", 
		"URL=https://www.damai.cn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://g.alicdn.com/alilog/mlog/aplus_v2.js", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/entry/index.js?t=216713", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/nsv/1.0.60/ns_b_71_3_n.js", ENDITEM, 
		"Url=https://g.alicdn.com/secdev/sufei_data/3.7.2/index.js", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1U9R8GY9YBuNjy0FgXXcxcXXa-146-1822.png", ENDITEM, 
		"Url=https://g.alicdn.com/alilog/oneplus/entry.js?t=216713", ENDITEM, 
		"Url=https://api-gw.damai.cn/advert.html?type=1&_ksTS=1560337124131_18&callback=jsonp19", ENDITEM, 
		"Url=https://api-gw.damai.cn/cityList.html?_ksTS=1560337124155_50&callback=jsonp51", ENDITEM, 
		"Url=https://api-gw.damai.cn/navigation.html?_ksTS=1560337124162_67&callback=jsonp68", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=6&destCity=%E9%95%BF%E6%B2%99&_ksTS=1560337124175_113&callback=jsonp114", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=1&destCity=%E9%95%BF%E6%B2%99&_ksTS=1560337124170_85&callback=jsonp86", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=3&destCity=%E9%95%BF%E6%B2%99&_ksTS=1560337124173_99&callback=jsonp100", ENDITEM, 
		"Url=https://log.mmstat.com/v.gif?logtype=1&title=%E5%A4%A7%E9%BA%A6%E7%BD%91-%E5%85%A8%E7%90%83%E6%BC%94%E5%87%BA%E8%B5%9B%E4%BA%8B%E5%AE%98%E6%96%B9%E8%B4%AD%E7%A5%A8%E5%B9%B3%E5%8F%B0-100%25%E6%AD%A3%E5%93%81%E3%80%81%E5%85%88%E4%BB%98%E5%85%88%E6%8A%A2%E3%80%81%E5%9C%A8%E7%BA%BF%E9%80%89%E5%BA%A7%EF%BC%81&pre=https%3A%2F%2Fwww.damai.cn%2F&scr=1280x720&cna=gJuHFQJpXnQCAcp4CxqZ/85N&spm-cnt=a2oeg.home.0.0.591b23e1KFEJ4s&uidaplus=&aplus&pu_i=&asid=AQAAAADk2gBd8DmJPgAAAACYDTc0mNMmdg==&sidx=0&ckx=|&p"
		"=1&o=win10&b=ie11&s=1280x720&w=trident&ism=pc&cache=d09b9f6&lver=8.11.5&jsver=aplus_std&pver=0.7.1&tag=1&stag=-1&lstag=-1&_slog=0", ENDITEM, 
		"Url=https://api-gw.damai.cn//search.html?cat=100&destCity=%E9%95%BF%E6%B2%99&_ksTS=1560337124178_127&callback=jsonp128", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01qMYyy62GdSB5YH1gA_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01lAtPPM2GdSAoNVqgT_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01Cxa37R2GdS9zUYfzL_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01HS0SWv2GdSAloJnxy_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01P8ZtMf2GdSAgWOEFl_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i2/2251059038/O1CN01qqdeSi2GdSA8XsDZa_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://pimg.dmcdn.cn/perform/project/1756/175686_n.jpg?_t=1555057823246", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01LRe9ds2GdS9xNKgfF_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01o9kVV12GdSAFet4Ke_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01Hd3P7M2GdS9msWHk7_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i2/2251059038/O1CN01gDNrbc2GdS97eZw9m_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN019xqMzT2GdSB3IUA64_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01YM3rmw2GdSAQtAjw7_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01wlouMw2GdS9s1TLcN_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01P4DEWS2GdSAZ6eul2_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i2/2251059038/O1CN01wTptpW2GdSAxpSRSz_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01jNGUHG2GdSAcIpyIV_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01PCrp8i2GdSAVV4pAE_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01MW0oPQ2GdSAYjaKkd_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01jlkFj72GdSApFzVrP_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://pimg.dmcdn.cn/perform/project/1761/176104_n.jpg?_t=1558510672050", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN018opqTW2GdSB0vG6hb_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i4/2251059038/O1CN01Pbgs5R2GdSB2KF18I_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01Y56plc2GdSAyHD5BA_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01H2jsds2GdSAsNq3Mf_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01linq3H2GdSAlcBETm_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i1/2251059038/O1CN01x7RMQs2GdS8gDb1pI_!!0-item_pic.jpg", ENDITEM, 
		"Url=https://img.alicdn.com/bao/uploaded/i2/2251059038/O1CN01CsEmEN2GdS9DkB0BI_!!0-item_pic.jpg", ENDITEM, 
		LAST);

	web_add_cookie("isg=BEREMdFaxTcAlXF7o64-GQfKHcI2XWjHNWBXbl7l0I_SieRThm04V3pvzeP0iqAf; DOMAIN=online.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc13yjXOCanurza77OSCRYYuPzaNbMi_5BK6T_VTQOkjpafF96VsCRsV8B4o5D9zJ9-etkq; DOMAIN=online.damai.cn");

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=online.damai.cn");

	web_url("getDialogToken_2", 
		"URL=https://online.damai.cn/alime/getDialogToken?_ksTS=1560337124139_37&callback=jsonCallback&from=damai_pc&jsonCallback=jsonCallback", 
		"Resource=0", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blk.html_2", 
		"URL=https://g.alicdn.com/alilog/oneplus/blk.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("SRCHUID=V=2&GUID=940318E86E70401AA47527F913EBA4F7&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20190204; DOMAIN=iecvlist.microsoft.com");

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1478281996/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("isg=BAIC86NU690ysPcB0fDgg9W8Wwhk0wbtpzZRdEwaP3X9n6EZNGOc_VedS1lG1H6F; DOMAIN=piao.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=piao.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=piao.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=piao.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc17SDBOfaKurza779gIO11kPzaNbMiICPOd1k3u6RWZhvQP8DC31Aa6IvR3rViBUyBqYK5yUBR; DOMAIN=piao.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=piao.damai.cn");

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=piao.damai.cn");

	web_add_cookie("isg=BAIC86NU690ysPcB0fDgg9W8Wwhk0wbtpzZRdEwaP3X9n6EZNGOc_VedS1lG1H6F; DOMAIN=www.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc17SDBOfaKurza779gIO11kPzaNbMiICPOd1k3u6RWZhvQP8DC31Aa6IvR3rViBUyBqYK5yUBR; DOMAIN=www.damai.cn");

	web_url("176104.html", 
		"URL=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://g.alicdn.com/??damai/pc-wx/0.1.0/index.css", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://g.alicdn.com/??damai/pc-wx/0.1.4/index.js", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://g.alicdn.com/mtb/lib-mtop/2.3.16/mtop.js", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://www.damai.cn/dm2015/images/siteseal_gd_3_h_l_m.gif", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://www.damai.cn/staticfile/Announcement/Announcement.js?937492837", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=/js/min/item-min.js?v3.12.18", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=/js/min/qa-min.js?v3.12.18", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		LAST);

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=detail.damai.cn");

	web_add_cookie("isg=BAIC86NU690ysPcB0fDgg9W8Wwhk0wbtpzZRdEwaP3X9n6EZNGOc_VedS1lG1H6F; DOMAIN=detail.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=detail.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=detail.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=detail.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc17SDBOfaKurza779gIO11kPzaNbMiICPOd1k3u6RWZhvQP8DC31Aa6IvR3rViBUyBqYK5yUBR; DOMAIN=detail.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=detail.damai.cn");

	web_add_cookie("isg=BAIC86NU690ysPcB0fDgg9W8Wwhk0wbtpzZRdEwaP3X9n6EZNGOc_VedS1lG1H6F; DOMAIN=secure.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=secure.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=secure.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=secure.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc17SDBOfaKurza779gIO11kPzaNbMiICPOd1k3u6RWZhvQP8DC31Aa6IvR3rViBUyBqYK5yUBR; DOMAIN=secure.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=secure.damai.cn");

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=secure.damai.cn");

	web_add_cookie("isg=BAIC86NU690ysPcB0fDgg9W8Wwhk0wbtpzZRdEwaP3X9n6EZNGOc_VedS1lG1H6F; DOMAIN=cp.damai.cn");

	web_add_cookie("t=4d7235666549ab3f54a0d9aa895efb49; DOMAIN=cp.damai.cn");

	web_add_cookie("munb=4019966623; DOMAIN=cp.damai.cn");

	web_add_cookie("cna=gJuHFQJpXnQCAcp4CxqZ/85N; DOMAIN=cp.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc17SDBOfaKurza779gIO11kPzaNbMiICPOd1k3u6RWZhvQP8DC31Aa6IvR3rViBUyBqYK5yUBR; DOMAIN=cp.damai.cn");

	web_add_cookie("damai.cn_nickName=skyyy1; DOMAIN=cp.damai.cn");

	web_add_cookie("destCity=%u957F%u6C99; DOMAIN=cp.damai.cn");

	web_add_cookie("isg=BFpa85FX01VbdF_5OTiIO230owB8i95lT-75bGTTF-241_oRTBpcdVklo2FuHFb9; DOMAIN=piao.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1AUtKOCanurza77O7CRYYuPzaNbMi_5N16L6aa_OkjpGaFp6VsCRs08B4o5D9zJ9-etkm; DOMAIN=piao.damai.cn");

	web_url("item.htm", 
		"URL=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://secure.damai.cn/static/jquery.playalert3.js?0001", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2014/common/img/police.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/img/kehuduan.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/??dm_2015/goods/site/js/common-min.js?v3.12.18,dm_2015/goods/site/js/search-min.js?v3.12.18,dm_2015/goods/site/js/widgetUIDs-min.js?v3.12.18,dm_2015/goods/site/js/calendarSettings-min.js,dm_2015/goods/site/js/calendar-min.js,dm_2015/goods/site/js/weixin-min.js,dm_2015/goods/site/js/json2-min.js,dm_2015/goods/site/js/datepicker-min.js,dm_2015/goods/site/js/app-min.js?v3.12.18", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2014/common/img/logo/dzyy.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=/subpage?itemId=592315236762&dmChannel=pc@damai_pc&dataId=210037298&dataType=2&bizCode=ali.china.damai&scenario=itemsku&privilegeActId=&callback=__jp0", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://g.alicdn.com/kissy/k/6.2.4/??base.js,attribute.js,event-custom.js,event-base.js,io.js,io-extra.js,io-base.js,promise.js,dom-base.js,query-selector-base.js,dom-extra.js,io-form.js,node.js,node-base.js,node-event.js,event-dom-base.js,event-dom-extra.js,event-gesture.js,event-touch.js,node-anim.js,anim-transition.js,anim-base.js", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/site/map/js/mapview.js", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://cp.damai.cn/js/Service51La/SeoFlowStatistics.js?45", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/js/jquery-1.8.2.min.js", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/??dm_2015/goods/css/style.css?v3.12.18,damai_v2/login_register3.0/css/style.css?v3.12.18", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://g.alicdn.com/alilog/??s/8.11.5/plugin/aplus_client.js,aplus_cplugin/0.7.1/toolkit.js,aplus_cplugin/0.7.1/monitor.js,s/8.11.5/plugin/aplus_ae.js,s/8.11.5/aplus_std.js,s/8.11.5/plugin/aplus_spmact.js?v=20190611144438", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://piao.damai.cn/img/loading.gif", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/m-logo-172-64.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/m-box-line.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/i-02.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/ultimate-sprites.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/m-countdown-bg.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/i-01.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://pimg.dmcdn.cn/perform/project/1761/176104_n.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/m-tab-dot.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/user.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/m-agent-logo.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		LAST);

	web_add_cookie("cpSTAT_ok_pages=1; DOMAIN=piao.damai.cn");

	web_add_cookie("cpSTAT_ok_times=1; DOMAIN=piao.damai.cn");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("cainiXihuan.html", 
		"URL=https://piao.damai.cn/ajax/cainiXihuan.html?type=1&projectids=176104&cityid=872", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("getInfo.html", 
		"URL=https://piao.damai.cn/ajax/getInfo.html?projectId=176104", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/site/weixin/shweixin.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		LAST);

	web_add_cookie("isg=BFpa85FX01VbdF_5OTiIO230owB8i95lT-75bGTTF-241_oRTBpcdVklo2FuHFb9; DOMAIN=www.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1AUtKOCanurza77O7CRYYuPzaNbMi_5N16L6aa_OkjpGaFp6VsCRs08B4o5D9zJ9-etkm; DOMAIN=www.damai.cn");

	web_revert_auto_header("X-Requested-With");

	web_url("bg_you_know.png", 
		"URL=https://dui.dmcdn.cn/damai_v2/goods/img/bg_you_know.png", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("176104", 
		"URL=https://piao.damai.cn/ajax/initPage/176104?t=1560337164174", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("isg=BHp6kCCF8_V7E3-ZGZjom41Uw6CcK_4Fb07ZzIRzJo3YdxqxbLtOFUCDw8EOfHad; DOMAIN=piao.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1GN3BOCanurza77OSCRYYuPzaNbMi_5ZL6L6K-QOkjpGGFp6VsCRs0LB4o5D9zJ9-etkc; DOMAIN=piao.damai.cn");

	web_add_cookie("DaMaiTicketHistory=ProList=176104%402019WWE%E7%BB%8F%E5%85%B8%E7%BE%8E%E5%BC%8F%E6%91%94%E8%B7%A4%E5%A8%B1%E4%B9%90%E7%A7%80%40sh; DOMAIN=piao.damai.cn");

	web_url("serverTime.aspx", 
		"URL=https://piao.damai.cn/serverTime.aspx?_=1560337164642", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://dui.dmcdn.cn/dm_2015/goods/images/m-choose-sel.png", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i1/2251059038/O1CN01AJKLh02GdSA0wefz2_!!2251059038.gif_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i3/2251059038/O1CN01c8BS0t2GdSA0xaSra_!!2251059038.gif_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i1/2251059038/O1CN01GIKUHi2GdSA0JoYZr_!!2251059038.gif_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i3/2251059038/O1CN015QeSGO2GdSA1ztwBK_!!2251059038.gif_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i3/2251059038/O1CN01AbXqKG2GdSA1uTOVa_!!2251059038.gif_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		LAST);

	web_add_cookie("isg=BE5OFH2Tn7mPCCudBXxUJ7n4lyQQzxLJO3JtyHiXqtEM2-414F4K2YedF8USWArh; DOMAIN=online.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1AUvBOCanurza77O7CRYYuPzaNbMi_5N16L6aa_OkjpGaFp6VsCRs08B4o5D9zJ9-etkm; DOMAIN=online.damai.cn");

	web_revert_auto_header("X-Requested-With");

	web_url("getDialogToken_3", 
		"URL=https://online.damai.cn/alime/getDialogToken?_ksTS=1560337163047_20&callback=jsonCallback&from=damai_pc&jsonCallback=jsonCallback", 
		"Resource=0", 
		"Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("yhcx.html", 
		"URL=https://piao.damai.cn/ajax/yhcx.html?projectid=176104&cityid=872&categoryID=6", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://img.alicdn.com/tfs/TB1S_dkRQvoK1RjSZFNXXcxMVXa-270-364.png", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://damaipimg.oss-cn-beijing.aliyuncs.com/cfs/src/cf23ea3e-558b-4a2b-9dbd-0ee51ebba97d.png?x-oss-process=image/resize,w_1/format,webp", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		LAST);

	web_add_cookie("isg=BHZ2nEQZN8HnR8MlvbQsL6Egz6x4l7rREzpFUOBfYtn0Ixa9SCcK4dzTPz3qkLLp; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1GNkBOCanurza77OSCRYYuPzaNbMi_5ZL6L6K-QOkjpGGFp6VsCRs0LB4o5D9zJ9-etkc; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BHZ2nEQZN8HnR8MlvbQsL6Egz6x4l7rREzpFUOBfYtn0Ixa9SCcK4dzTPz3qkLLp; DOMAIN=piao.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1GNkBOCanurza77OSCRYYuPzaNbMi_5ZL6L6K-QOkjpGGFp6VsCRs0LB4o5D9zJ9-etkc; DOMAIN=piao.damai.cn");

	web_add_cookie("cn_7415364c9dab5n09ff68_dplus=%7B%22distinct_id%22%3A%20%2216b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943%22%7D; DOMAIN=piao.damai.cn");

	web_add_cookie("UM_distinctid=16b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943; DOMAIN=piao.damai.cn");

	web_url("GetQA.html", 
		"URL=https://piao.damai.cn/ajax/GetQA.html?pid=176104&t=0.7589793015600013&pageidx=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://img.alicdn.com/imgextra/i3/2251059038/O1CN01YbZ0SH2GdSA3MZ3Ur_!!2251059038.gif_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i2/2251059038/O1CN01qqdeSi2GdSA8XsDZa_!!0-item_pic.jpg_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/11.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1b7uJRSrqK1RjSZK9XXXyypXa-24-24.png", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1d7mWRMHqK1RjSZFEXXcGMXXa-24-26.png", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1gKnkSMTqK1RjSZPhXXXfOFXa-28-28.png", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/2.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://img.alicdn.com/tfs/TB1r0uFxHSYBuNjSspiXXXNzpXa-280-280.png", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://damai-item.oss-cn-beijing.aliyuncs.com/projQcode/5923152367/2/592315236762.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/10.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://api-gw.damai.cn/navigation.html?_ksTS=1560337163063_35&callback=jsonp36", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/57.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://static.dmcdn.cn/Erweima/1761/176104.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/12.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/23.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/14.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/17.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://log.mmstat.com/eg.js", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://w.cnzz.com/dplus.define.php", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://w.cnzz.com/dplus.php?token=7415364c9dab5n09ff68", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/13.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		"Url=../favicon.ico", "Referer=", ENDITEM, 
		"Url=https://static.dmcdn.cn/PayLogo/15.jpg", "Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("blk.html_3", 
		"URL=https://g.alicdn.com/alilog/oneplus/blk.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blk.html_4", 
		"URL=https://g.alicdn.com/alilog/oneplus/blk.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://detail.damai.cn");

	web_url("gl.html", 
		"URL=https://search.damai.cn/external/gl.html?type=1&projects=592315236762", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01lAtPPM2GdSAoNVqgT_!!0-item_pic.jpg_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_0.ditem_5.591b23e1KFEJ4s&id=592315236762", ENDITEM, 
		LAST);

	web_add_cookie("cn_7415364c9dab5n09ff68_dplus=%7B%22distinct_id%22%3A%20%2216b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943%22%2C%22%24_sessionid%22%3A%201%2C%22%24_sessionTime%22%3A%201560337172%2C%22%24dp%22%3A%200%2C%22%24_sessionPVTime%22%3A%201560337172%2C%22initial_view_time%22%3A%20%221560337002%22%2C%22initial_referrer%22%3A%20%22https%3A%2F%2Fwww.damai.cn%2F%22%2C%22initial_referrer_domain%22%3A%20%22www.damai.cn%22%7D; DOMAIN=detail.damai.cn");

	web_add_cookie("isg=BMLCu2mvK51zETfBkTCgw5V8G8gkk8atZ3YRtAzbADXdX2LZ9CLivUncC5mGFD5F; DOMAIN=detail.damai.cn");

	web_add_cookie("UM_distinctid=16b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943; DOMAIN=detail.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1lZKBOfChurza77OfIR_4kPzaNbMiICPszfHuQ75WZhvIOYMC31Aw10BR3rViBUyBeYBqg5..; DOMAIN=detail.damai.cn");

	web_url("item.htm_2", 
		"URL=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.damai.cn/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/subpage?itemId=596174806847&dmChannel=pc@damai_pc&dataId=210055118&dataType=2&bizCode=ali.china.damai&scenario=itemsku&privilegeActId=&callback=__jp0", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		LAST);

	web_add_cookie("cn_7415364c9dab5n09ff68_dplus=%7B%22distinct_id%22%3A%20%2216b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943%22%2C%22%24_sessionid%22%3A%201%2C%22%24_sessionTime%22%3A%201560337172%2C%22%24dp%22%3A%200%2C%22%24_sessionPVTime%22%3A%201560337172%2C%22initial_view_time%22%3A%20%221560337002%22%2C%22initial_referrer%22%3A%20%22https%3A%2F%2Fwww.damai.cn%2F%22%2C%22initial_referrer_domain%22%3A%20%22www.damai.cn%22%7D; DOMAIN=www.damai.cn");

	web_add_cookie("isg=BMLCu2mvK51zETfBkTCgw5V8G8gkk8atZ3YRtAzbADXdX2LZ9CLivUncC5mGFD5F; DOMAIN=www.damai.cn");

	web_add_cookie("UM_distinctid=16b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943; DOMAIN=www.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1lZKBOfChurza77OfIR_4kPzaNbMiICPszfHuQ75WZhvIOYMC31Aw10BR3rViBUyBeYBqg5..; DOMAIN=www.damai.cn");

	web_url("ajax.aspx", 
		"URL=https://www.damai.cn/ajax.aspx?type=388&cityID=undefined&URL=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s&_=1560337171917", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://piao.damai.cn/176104.html?spm=a2oeg.home.card_2.ditem_6.591b23e1KFEJ4s", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://img.alicdn.com/imgextra/i1/2251059038/O1CN019xqMzT2GdSB3IUA64_!!0-item_pic.jpg_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://detail.damai.cn");

	web_url("gl.html_2", 
		"URL=https://search.damai.cn/external/gl.html?type=1&projects=596174806847", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://img.alicdn.com/bao/uploaded/i3/2251059038/O1CN01wcbnon2GdSAzuiXuI_!!0-item_pic.jpg_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		LAST);

	web_add_cookie("cn_7415364c9dab5n09ff68_dplus=%7B%22distinct_id%22%3A%20%2216b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943%22%2C%22%24_sessionid%22%3A%200%2C%22%24_sessionTime%22%3A%201560337183%2C%22%24dp%22%3A%200%2C%22%24_sessionPVTime%22%3A%201560337183%2C%22initial_view_time%22%3A%20%221560337002%22%2C%22initial_referrer%22%3A%20%22https%3A%2F%2Fwww.damai.cn%2F%22%2C%22initial_referrer_domain%22%3A%20%22www.damai.cn%22%7D; DOMAIN=online.damai.cn");

	web_add_cookie("isg=BJKSSEgNGy0jCGdRISBQU-Vs61h0o5Y910YhBFzrT8UubzJpRDHLTZjM2wl2BA7V; DOMAIN=online.damai.cn");

	web_add_cookie("UM_distinctid=16b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943; DOMAIN=online.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1hspBOfClurza779BIR_4kPzaNbMiICP_xCp7p2AWZhvIt89C31Aw10BR3rViBUyBeYBqg5..; DOMAIN=online.damai.cn");

	web_add_cookie("cn_7415364c9dab5n09ff68_dplus=%7B%22distinct_id%22%3A%20%2216b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943%22%2C%22%24_sessionid%22%3A%200%2C%22%24_sessionTime%22%3A%201560337183%2C%22%24dp%22%3A%200%2C%22%24_sessionPVTime%22%3A%201560337183%2C%22initial_view_time%22%3A%20%221560337002%22%2C%22initial_referrer%22%3A%20%22https%3A%2F%2Fwww.damai.cn%2F%22%2C%22initial_referrer_domain%22%3A%20%22www.damai.cn%22%7D; DOMAIN=api-gw.damai.cn");

	web_add_cookie("isg=BJKSSEgNGy0jCGdRISBQU-Vs61h0o5Y910YhBFzrT8UubzJpRDHLTZjM2wl2BA7V; DOMAIN=api-gw.damai.cn");

	web_add_cookie("UM_distinctid=16b4b57c589139-0876a5a123cebf-771c3e02-e1000-16b4b57c58a943; DOMAIN=api-gw.damai.cn");

	web_add_cookie("l=bBMoFGFHqQjc1hspBOfClurza779BIR_4kPzaNbMiICP_xCp7p2AWZhvIt89C31Aw10BR3rViBUyBeYBqg5..; DOMAIN=api-gw.damai.cn");

	web_url("getDialogToken_4", 
		"URL=https://online.damai.cn/alime/getDialogToken?_ksTS=1560337178401_20&callback=jsonCallback&from=damai_pc&jsonCallback=jsonCallback", 
		"Resource=0", 
		"Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://img.alicdn.com/imgextra/i2/2251059038/O1CN01UrRYBK2GdSB3vbGYY_!!2251059038.jpg_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		"Url=https://damai-item.oss-cn-beijing.aliyuncs.com/projQcode/5961748068/2/596174806847.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		"Url=https://api-gw.damai.cn/navigation.html?_ksTS=1560337178417_35&callback=jsonp36", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		"Url=https://img.alicdn.com/imgextra/i3/2251059038/O1CN01jbOdSc2GdSB1SUq2Q_!!2251059038.jpg_q60.jpg", "Referer=https://detail.damai.cn/item.htm?spm=a2oeg.home.card_1.ditem_4.591b23e1KFEJ4s&id=596174806847", ENDITEM, 
		LAST);

	return 0;
}